def split_original_file(input_file, output_prefix, chunk_size=1000):
    """
    按固定行数分割文件，保留所有原始内容（包括空行和格式）
    :param input_file: 输入文件名
    :param output_prefix: 输出文件前缀（如output_）
    :param chunk_size: 每个文件行数（默认1000）
    """
    with open(input_file, 'r') as f:
        buffer = []
        file_index = 1

        for line_num, line in enumerate(f, 1):
            buffer.append(line)

            # 每达到chunk_size行时写入文件
            if line_num % chunk_size == 0:
                output_file = f"{output_prefix}{file_index}.fasta"
                with open(output_file, 'w') as out:
                    out.writelines(buffer)
                buffer = []
                file_index += 1

        # 处理最后未满chunk_size的剩余行
        if buffer:
            output_file = f"{output_prefix}{file_index}.fasta"
            with open(output_file, 'w') as out:
                out.writelines(buffer)


# 使用示例
split_original_file("test.txt", "test_", chunk_size=1000)