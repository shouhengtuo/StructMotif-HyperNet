
from model import *
from torch.utils.data import DataLoader
from loss_functions import *
from train import *
from getData import graphData

torch.autograd.set_detect_anomaly(True)
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
# DEVICE = torch.device("cpu")
filenames = ['AAP', 'ABP', 'ACP', 'ACVP', 'ADP', 'AEP', 'AFP', 'AHIVP', 'AHP', 'AIP', 'AMRSAP', 'APP', 'ATP',
             'AVP',
             'BBP', 'BIP',
             'CPP', 'DPPIP',
             'QSP', 'SBP', 'THP']


def PadEncode(data, label, max_len):
    """
    Encode amino acid sequences into numerical indices and pad them to a uniform length

    Parameters:
    data (list): List of amino acid sequences
    label (list): Corresponding list of labels
    max_len (int): Maximum length for sequence padding

    Returns:
    tuple: Encoded and padded sequences, labels, and original sequence lengths (as numpy arrays)
    """
    amino_acids = 'XACDEFGHIKLMNPQRSTVWY'  # Amino acid alphabet, X represents unknown amino acid
    data_e, label_e, seq_length, temp = [], [], [], []  # Initialize result lists
    sign, b = 0, 0  # sign: flag for invalid amino acids; b: counter for valid sequences

    # Iterate through each sequence
    for i in range(len(data)):
        length = len(data[i])  # Length of current sequence
        elemt, st = [], data[i].strip()  # elemt: stores numerical indices; st: processed sequence

        # Convert amino acids to numerical indices
        for j in st:
            if j not in amino_acids:  # Check for invalid amino acids
                sign = 1  # Set flag for invalid sequence
                break
            index = amino_acids.index(j)  # Get index in the amino acid alphabet
            elemt.append(index)
            sign = 0  # Reset flag for valid amino acid

        # Process sequence if length is within limit and no invalid amino acids
        if length <= max_len and sign == 0:
            temp.append(elemt)  # Store original encoded sequence (before padding)
            seq_length.append(len(temp[b]))  # Record original sequence length
            b += 1
            elemt += [0] * (max_len - length)  # Pad with zeros to reach max_len
            data_e.append(elemt)  # Add padded sequence to result
            label_e.append(label[i])  # Add corresponding label

    return np.array(data_e), np.array(label_e), np.array(seq_length)


def getSequenceData(first_dir, file_name):
    """
    Load sequence data and corresponding labels from a text file

    Parameters:
    first_dir (str): Directory containing the file
    file_name (str): Name of the file (without extension)

    Returns:
    tuple: List of sequences and list of corresponding labels
    """
    # Initialize lists to store data and labels
    data, label = [], []
    path = "{}/{}.txt".format(first_dir, file_name)  # Construct full file path

    # Read file content
    with open(path) as f:
        for each in f:
            each = each.strip()  # Remove leading/trailing whitespace
            if each[0] == '>':  # Lines starting with '>' contain labels
                # Convert label string to numeric vector
                label.append(np.array(list(each[1:]), dtype=int))
            else:  # Other lines contain amino acid sequences
                data.append(each)

    return data, label




def main(num, data):
# def main(data):
    first_dir = 'dataset'

    max_length = 50  # the longest length of the peptide sequence

    # getting train data and test data
    train_sequence_data, train_sequence_label = getSequenceData(first_dir, 'train')
    test_sequence_data, test_sequence_label = getSequenceData(first_dir, 'test')

    # Converting the list collection to an array
    y_train = np.array(train_sequence_label)
    y_test = np.array(test_sequence_label)

    # The peptide sequence is encoded and the sequences that do not conform to the peptide sequence are removed

    x_train0, y_train, train_length = PadEncode(train_sequence_data, y_train, max_length)
    x_test0, y_test, test_length = PadEncode(test_sequence_data, y_test, max_length)



    # 2、为训练数据和测试数据拼接图模型特征: 图模型的输出在一个文件中

    loaded_array = np.loadtxt('hyg_feature.txt')
    # loaded_array = np.loadtxt('random_numbers.txt')
    hyGx_train = loaded_array[0:7873, :]
    hyGx_test = loaded_array[7873:, :] # [1919]
    hyGx_train = torch.Tensor(hyGx_train)
    hyGx_test = torch.Tensor(hyGx_test)

    train_loader,test_loader=graphData(x_train0,x_test0,hyGx_train,hyGx_test)


    # 设置训练参数
    vocab_size = 50
    output_size = 21

    model = ETFC(vocab_size, data['embedding_size'], output_size, data['dropout'])

    rate_learning = data['learning_rate']
    optimizer = torch.optim.Adam(model.parameters(), lr=rate_learning)
    criterion = FocalDiceLoss(clip_pos=data['clip_pos'], clip_neg=data['clip_neg'], pos_weight=data['pos_weight'])

    # 创建初始化训练类
    Train = DataTrain(model, optimizer, criterion,device=DEVICE)
    a = time.time()
    # Train.train_step(train_loader, test_loader,epochs=data['epochs'], plot_picture=False)
    b = time.time()
    runtime = b - a
    # model.load_state_dict(torch.load('result/GT656.pkl'))
    with torch.no_grad():
        model.load_state_dict(torch.load('result/best_model_880.pkl'))

        test_score = evaluate(model,test_loader, device=DEVICE)
    #    test_score = evaluate(self.model, dataset_test,device=DEVICE)


    "-------------------------------------------输出模型结果-----------------------------------------------"
    print(f"runtime:{runtime:.3f}s")
    print("测试集：")
    print(f'aiming: {test_score["aiming"]:.3f}')
    print(f'coverage: {test_score["coverage"]:.3f}')
    print(f'accuracy: {test_score["accuracy"]:.3f}')
    print(f'absolute_true: {test_score["absolute_true"]:.3f}')
    print(f'absolute_false: {test_score["absolute_false"]:.3f}')



# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    clip_pos = 0.7
    clip_neg = 0.5
    pos_weight = 0.3

    batch_size = 192
    epochs = 100
    learning_rate = 0.0018
    embedding_size = 256
    dropout = 0.6
    para = {'clip_pos': clip_pos,
            'clip_neg': clip_neg,
            'pos_weight': pos_weight,
            'batch_size': batch_size,
            'epochs': epochs,
            'learning_rate': learning_rate,
            'embedding_size': embedding_size,
            'dropout': dropout,}
    main(1, para)