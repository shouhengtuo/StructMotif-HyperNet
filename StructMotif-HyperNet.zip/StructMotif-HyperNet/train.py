import time
import torch
import math
import numpy as np
from sklearn import metrics
# from torchinfo import summary
from torch.optim import lr_scheduler
from torch.optim.lr_scheduler import LambdaLR
import evaluation
import matplotlib.pyplot as plt

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")


def evaluate(model, datadl, device):
    """
    Evaluate model performance on given dataset

    Args:
        model: Trained model
        datadl: DataLoader for evaluation data
        device: Device to run model on (CPU/GPU)

    Returns:
        Dictionary of evaluation metrics
    """
    model.to(device)
    model.eval()
    predictions = []
    labels = []

    with torch.no_grad():
        for batch in datadl:
            # Get batch data and move to device
            seq = batch["seq"].to(device)  # Sequence data (B, 50)
            train_label = batch["label"].to(device)  # Labels (B,)
            adj_edges = [edge.to(device) for edge in batch["adj"]]  # Adjacency edges
            hyper_edges = torch.stack(batch["hyper"], dim=0).to(device)  # Hypergraph edges

            # Collect model predictions and true labels
            predictions.extend(model(seq, adj_edges, hyper_edges).tolist())
            labels.extend(train_label.tolist())

    # Calculate evaluation metrics using external evaluation module
    scores = evaluation.evaluate(np.array(predictions), np.array(labels))
    return scores


def scoring(y_true, y_score):
    """
    Calculate classification performance metrics

    Args:
        y_true: Ground truth labels
        y_score: Predicted probabilities

    Returns:
        Dictionary of performance metrics
    """
    threshold = 0.5
    y_pred = [int(i >= threshold) for i in y_score]

    # Calculate confusion matrix and metrics
    confusion_matrix = metrics.confusion_matrix(y_true, y_pred)
    tn, fp, fn, tp = confusion_matrix.flatten()

    # Compute standard classification metrics
    sen = tp / (fn + tp)  # Sensitivity/Recall
    spe = tn / (fp + tn)  # Specificity
    pre = metrics.precision_score(y_true, y_pred)  # Precision
    auc = metrics.roc_auc_score(y_true, y_score)  # AUC-ROC
    pr, rc, _ = metrics.precision_recall_curve(y_true, y_score)
    aupr = metrics.auc(rc, pr)  # AUC-PR
    f1 = metrics.f1_score(y_true, y_pred)  # F1-score
    mcc = metrics.matthews_corrcoef(y_true, y_pred)  # MCC
    acc = metrics.accuracy_score(y_true, y_pred)  # Accuracy

    return dict(SEN=sen, SPE=spe, PRE=pre, F1=f1, MCC=mcc, ACC=acc, AUC=auc, AUPR=aupr, TN=tn, FP=fp, FN=fn, TP=tp)


class DataTrain:
    """
    Training manager for models with hypergraph inputs
    """

    def __init__(self, model, optimizer, criterion, device="cuda", *args, **kwargs):
        """
        Initialize training manager

        Args:
            model: Model to train
            optimizer: Optimizer for training
            criterion: Loss function
            device: Device to run training on
        """
        self.model = model
        self.optimizer = optimizer
        self.criterion = criterion
        self.device = device
        self.model.to(self.device)

    def train_step(self, train_iter, dataset_test, epochs=None, plot_picture=False):
        """
        Perform training for specified epochs

        Args:
            train_iter: Training data iterator
            dataset_test: Test dataset for validation
            epochs: Number of training epochs
            plot_picture: Whether to plot learning rate curve
        """
        x_plot = []  # For plotting learning rate
        y_plot = []  # For plotting learning rate

        best_aiming = 0  # Track best validation aiming score

        for epoch in range(1, epochs + 1):
            start = time.time()
            total_loss = 0

            # Training loop
            for i, batch in enumerate(train_iter):
                self.model.train()

                # Get and prepare batch data
                seq = batch["seq"].to(self.device)
                train_label = batch["label"].to(self.device)
                adj_edges = [edge.to(self.device) for edge in batch["adj"]]
                hyper_edges = torch.stack(batch["hyper"], dim=0).to(self.device)

                # Forward pass
                y_hat = self.model(seq, adj_edges, hyper_edges)

                # Calculate and print training metrics periodically
                if i % 30 == 0:
                    train_scores = evaluation.evaluate(
                        np.array(y_hat.tolist()),
                        np.array(train_label.tolist())
                    )
                    print(f'aiming: {train_scores["aiming"]:.3f}')
                    print(f'coverage: {train_scores["coverage"]:.3f}')
                    print(f'accuracy: {train_scores["accuracy"]:.3f}')
                    print(f'absolute_true: {train_scores["absolute_true"]:.3f}')
                    print(f'absolute_false: {train_scores["absolute_false"]:.3f}')

                # Backpropagation
                loss = self.criterion(y_hat, train_label.float())
                self.optimizer.zero_grad()
                loss.backward()
                self.optimizer.step()

            # Validation after each epoch
            finish = time.time()
            with torch.no_grad():
                test_score = evaluate(self.model, dataset_test, device=DEVICE)
                test_aiming = test_score["aiming"]

                # Save best model based on validation aiming
                if test_aiming > best_aiming:
                    best_aiming = test_aiming
                    torch.save(self.model.state_dict(), 'result/new——btd_123.pkl')

            # Print epoch summary
            print(f'[ Epoch {epoch}', end='')
            print(f" 运行时间{finish - start:.2f}s", end='')
            print(f' loss={loss:.4f}', end='')
            print(f' val_aiming={test_aiming:.4f}]')

            # Record learning rate for plotting
            if plot_picture:
                current_lr = self.optimizer.param_groups[0]['lr']
                x_plot.append(epoch)
                y_plot.append(current_lr)

        # Plot learning rate curve if specified
        if plot_picture:
            plt.plot(x_plot, y_plot, 'r')
            plt.title('Learning Rate Schedule (Cosine Warmup)')
            plt.xlabel('Epoch')
            plt.ylabel('Learning Rate')
            plt.savefig('./result/Cos_warmup.jpg')


class CosineScheduler:
    """
    Cosine learning rate scheduler with warmup phase
    """

    def __init__(self, max_update, base_lr=0.01, final_lr=0, warmup_steps=0, warmup_begin_lr=0):
        """
        Initialize cosine scheduler

        Args:
            max_update: Maximum number of updates
            base_lr: Base learning rate
            final_lr: Final learning rate after decay
            warmup_steps: Number of warmup steps
            warmup_begin_lr: Starting learning rate for warmup
        """
        self.base_lr_orig = base_lr
        self.max_update = max_update
        self.final_lr = final_lr
        self.warmup_steps = warmup_steps
        self.warmup_begin_lr = warmup_begin_lr
        self.max_steps = self.max_update - self.warmup_steps

    def get_warmup_lr(self, epoch):
        """Calculate warmup learning rate"""
        increase = (self.base_lr_orig - self.warmup_begin_lr) * float(epoch - 1) / float(self.warmup_steps)
        return self.warmup_begin_lr + increase

    def __call__(self, epoch):
        """Get learning rate for current epoch"""
        if epoch < self.warmup_steps:
            # Warmup phase
            return self.get_warmup_lr(epoch)
        elif epoch <= self.max_update:
            # Cosine decay phase
            self.base_lr = self.final_lr + (self.base_lr_orig - self.final_lr) * \
                           (1 + math.cos(math.pi * (epoch - 1 - self.warmup_steps) / self.max_steps)) / 2
            return self.base_lr
        else:
            # After max updates, use final lr
            return self.final_lr