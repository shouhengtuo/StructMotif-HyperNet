
import math

from torch.utils.data import Dataset
from torch_geometric.data import Data
from Bio.PDB import PDBParser
import numpy as np

import torch
from torch_geometric.data import Data


class CustomData(Data):
    def __inc__(self, key, value, *args, **kwargs):
        # 告诉PyG如何增加索引（针对边索引和其他需要递增的属性）
        if key == 'edge_index':
            return self.x.size(0)  # 边索引需要递增节点数
        if key == 'extra_info':
            return 0  # extra_info不需要递增（它是全局特征）
        else:
            return super().__inc__(key, value, *args, **kwargs)

    def __cat_dim__(self, key, value, *args, **kwargs):
        # 告诉PyG如何拼接张量
        if key == 'edge_index':
            return 1  # 边索引在第二维拼接
        if key == 'extra_info':
            return 0  # extra_info在第一维（批次维度）拼接
        else:
            return super().__cat_dim__(key, value, *args, **kwargs)


import torch
from torch.utils.data import Dataset, DataLoader


class MultiFeatureDataset(Dataset):
    def __init__(self, data_list):
        self.data = data_list  # 每个元素是 (seq, adj_edges, label, hyper_edges)

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        seq, edges, label, hyper = self.data[idx]
        # 转为Tensor（邻接矩阵和超图保持为边列表格式）
        return (
            torch.tensor(seq, dtype=torch.long),  # 序列特征 (50,)
            torch.tensor(edges, dtype=torch.long).t(),  # 邻接边列表 (2, num_edges)
            torch.tensor(label, dtype=torch.long),  # 标签 (1,)
            hyper  # 超图边列表 (2, num_hyperedges)
        )

def load_sequence_labels(label_file):
    """加载序列标签数据，返回{sequence: labels}字典"""
    data, label = [], []
    with open(label_file) as f:
        for each in f:
            each = each.strip()
            if each[0] == '>':
                label.append(np.array(list(each[1:]), dtype=int))  # Converting string labels to numeric vectors
            else:
                data.append(each)

    return data, label
# 氨基酸到索引的映射字典
aa_to_idx = {
    'A': 0, 'R': 1, 'N': 2, 'D': 3, 'C': 4,
    'Q': 5, 'E': 6, 'G': 7, 'H': 8, 'I': 9,
    'L': 10, 'K': 11, 'M': 12, 'F': 13, 'P': 14,
    'S': 15, 'T': 16, 'W': 17, 'Y': 18, 'V': 19,
    'X': 20  # 未知氨基酸
}
def parse_pdb_chains(pdb_path):
    """返回包含(chain_id, sequence, ca_coords)的元组列表"""
    """手动解析PDB文件，按TER记录或残基编号重置分割结构"""
    all_structures = []
    current_structure = []
    last_residue_id = None

    with open(pdb_path, 'r') as f:
        for line in f:
            if line.startswith('TER') or line.startswith('END'):
                # 遇到TER或END，保存当前结构
                if len(current_structure) > 0:
                    all_structures.append(np.array(current_structure))
                    current_structure = []
                last_residue_id = None
            elif line.startswith('ATOM'):
                # 提取残基信息和坐标
                residue_id = int(line[22:26].strip())  # 残基编号
                atom_name = line[12:16].strip()
                if atom_name == 'CA':
                    x = float(line[30:38])
                    y = float(line[38:47])
                    z = float(line[48:54])
                    # 检测残基编号是否重置（新结构开始）
                    if last_residue_id is not None and residue_id < last_residue_id:
                        if len(current_structure) > 0:
                            all_structures.append(np.array(current_structure))
                            current_structure = []
                    current_structure.append([x, y, z])
                    last_residue_id = residue_id

    # 添加最后一个结构
    if len(current_structure) > 0:
        all_structures.append(np.array(current_structure))

    return all_structures


def build_protein_graph(coords,seq,hy, k_nearest=2):
    """构建蛋白质图结构
    参数：
        coords: [N, 3] CA原子坐标
        sequence: 长度N的氨基酸序列
        k_nearest: 空间最近邻连接数
    返回：
        Data: 图数据对象
    """
    # 将氨基酸转换为索引
    # node_feature = torch.tensor([aa_to_idx[aa] for aa in sequence], dtype=torch.long)
    # seq_length = len(sequence)
    # node_features = [node_feature,seq_length]
    # 构建边连接（基于空间距离）
    dist_matrix = torch.cdist(torch.FloatTensor(coords), torch.FloatTensor(coords))
    seq = torch.Tensor(seq)
    # 选择每个节点的k个最近邻（排除自身）
    _, topk_indices = torch.topk(dist_matrix, k=k_nearest + 1, dim=1, largest=False)
    edge_index = []
    for i in range(len(coords)):
        for j in topk_indices[i][1:]:  # 跳过第一个（自己）
            edge_index.append([i, j])
            edge_index.append([j, i])  # 无向图
    # # 构建边（基于质心距离）
    # nodes = coords
    # # 计算距离矩阵（节点之间的欧氏距离）
    # dist_matrix = np.sqrt(np.sum((nodes[:, None] - nodes) ** 2, axis = 2))
    #
    # # 创建边（假设距离阈值设为 1.0）
    # edge_index = []
    # for i in range(len(nodes)):
    #     for j in range(i + 1, len(nodes)):
    #         if dist_matrix[i, j] < 5.0:  # 使用固定距离阈值
    #             edge_index.append([i, j])
    #             edge_index.append([j, i])  # 无向图
    # dtype = torch.long
    # data = Data(
    #     x=seq,
    #     edge_index=torch.LongTensor(edge_index).t().contiguous(),
    #     # coords=torch.FloatTensor(coords),
    #     # seq_lengths=node_features
    #     hyg=hy
    # )
    # data.extra_info = hyg
    return edge_index


