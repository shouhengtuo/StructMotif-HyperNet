
import torch
import torch.nn as nn
from torch_geometric.nn import GINConv, global_max_pool
# from torch_geometric.nn import GATv2Conv, global_mean_pool

import torch.nn.functional as F
# from torch_geometric.nn import HypergraphConv
class ETFC(nn.Module):
    def __init__(self, vocab_size, embedding_size, output_size, dropout, max_pool=5):
        super(ETFC, self).__init__()

        self.vocab_size = vocab_size
        self.embedding_size = embedding_size
        self.output_size = output_size
        self.dropout = dropout
        self.max_pool = max_pool
        self.embed = torch.nn.Embedding(self.vocab_size, self.embedding_size)

        self.conv1 = torch.nn.Conv1d(in_channels=self.embedding_size,
                                     out_channels=64,
                                     kernel_size=2,
                                     stride=1
                                     )
        self.conv2 = torch.nn.Conv1d(in_channels=self.embedding_size,
                                     out_channels=64,
                                     kernel_size=3,
                                     stride=1
                                     )
        self.conv3 = torch.nn.Conv1d(in_channels=self.embedding_size,
                                     out_channels=64,
                                     kernel_size=4,
                                     stride=1
                                     )
        self.conv4 = torch.nn.Conv1d(in_channels=self.embedding_size,
                                     out_channels=64,
                                     kernel_size=5,
                                     stride=1
                                     )
        # 序列最短为5，故将卷积核分别设为：2、3、4、5
        self.MaxPool1d = torch.nn.MaxPool1d(kernel_size=self.max_pool)

        self.full3 = nn.Linear(1152, 500)
        # self.full4 = nn.Linear(500, 250)
        self.full4 = nn.Linear(128+128+128, 250)
        self.full5 = nn.Linear(250, 128)
        self.full8 = nn.Linear(2304, 512)
        self.full10 = nn.Linear(512, 128)
        self.full11 = nn.Linear(embedding_size, 128)

        self.Tg = nn.Linear(256, 128)
        self.Flatten = nn.Linear(128, 64)
        self.out = nn.Linear(64, self.output_size)
        self.dropout = torch.nn.Dropout(self.dropout)
        self.full7 = nn.Linear(1536, 1152)

        # self.gincov1 = GATv2Conv(embedding_size, embedding_size//8, heads=num_heads)
        # self.gincov2 = GATv2Conv(embedding_size, embedding_size//8, heads=num_heads)
        # self.gincov1 = GATv2Conv(embedding_size, embedding_size, heads=num_heads)
        # self.gincov2 = GATv2Conv(embedding_size * num_heads, embedding_size, heads=1)
        # self.hyper_conv1 = GATv2Conv(embedding_size, embedding_size)
        # self.hyper_conv2 = GATv2Conv(embedding_size, embedding_size)
        # self.conv2 = GINConv(nn.Sequential(
        #     nn.Linear(hidden_dim, hidden_dim),
        #     nn.ReLU(),
        #     nn.Linear(hidden_dim, hidden_dim)
        # ))
        # self.gincov1 = GINConv(embedding_size, embedding_size)
        # self.gincov2 = GINConv(embedding_size, embedding_size)
        self.gincov1 = GINConv(nn.Sequential(
            nn.Linear(embedding_size, embedding_size),
        ))
        self.gincov2 = GINConv(nn.Sequential(
            nn.Linear(embedding_size, embedding_size),
        ))

    def TextCNN(self, x):
        x1 = self.conv1(x)
        x1 = torch.nn.ReLU()(x1)
        x1 = self.MaxPool1d(x1)

        x2 = self.conv2(x)
        x2 = torch.nn.ReLU()(x2)
        x2 = self.MaxPool1d(x2)

        x3 = self.conv3(x)
        x3 = torch.nn.ReLU()(x3)
        x3 = self.MaxPool1d(x3)

        x4 = self.conv4(x)
        x4 = torch.nn.ReLU()(x4)
        x4 = self.MaxPool1d(x4)
        #
        y = torch.cat([x1, x2, x3, x4], dim=-1)
        # y = torch.cat([x1, x2], dim=-1)

        x = self.dropout(y)

        x = x.view(x.size(0), -1)

        return x


    def forward(self, seqs,adj,hyGx_train,in_feat=False):



    #
        # AA_train_data0 = seqs.long()
    #
    #     hyg_data = hyGx_train # 这部分是超图特征 总共128维
    #
        AA_embed_output = self.embed(seqs)

        all_graph_features = []
        # 逐样本处理（因邻接矩阵结构不同）
        for i in range(len(seqs)):
            # 提取第i个样本的序列和邻接矩阵
            seq = AA_embed_output[i]  # (50, seq_feat_dim)
            edge_index = adj[i]  # (2, num_edges)


            # 图卷积
            x = self.gincov1(seq, edge_index)
            x = F.relu(x)
            x = self.gincov2(x, edge_index)
            # x = global_mean_pool(x, edge_index)
            # x = global_max_pool(x, 1)
            graph_feature = torch.mean(x, dim=0)  # (gcn_hidden_dim)
            all_graph_features.append(graph_feature)

        all_graph_features = torch.stack(all_graph_features, dim=0)
        AA_cnn_input = AA_embed_output.permute(0, 2, 1)
        AA_cnn_output = self.TextCNN(AA_cnn_input)




        # mean2 = hyGx_train.mean(dim=0, keepdim=True)
        # std2 = hyGx_train.std(dim=0, keepdim=True)
        # normalized_output2 = (hyGx_train - mean2) / std2
        # cnn_output0 = AA_cnn_output

        cnn_output = self.full8(AA_cnn_output)
        cnn_output = self.full10(cnn_output)
        graph_out = self.full11(all_graph_features)
        #
        #
        cnn_output0 = torch.cat([cnn_output, hyGx_train,graph_out], dim=-1)
        # cnn_output0 = torch.cat([cnn_output,graph_out], dim=-1)
        #
        # cnn_output = self.full7(cnn_output0)

        # # 全连接层
        # label = self.full3(cnn_output)
        # label = torch.nn.ReLU()(label)
        label1 = self.full4(cnn_output0)
        label = torch.nn.ReLU()(label1)
        label2 = self.full5(label)
        label = torch.nn.ReLU()(label2)
        label3 = self.Flatten(label)
        label = torch.nn.ReLU()(label3)
        out_label = self.out(label)


        # label2 = self.Tg(graph_out)
        #
        # label = torch.nn.ReLU()(label2)
        # label3 = self.Flatten(graph_out)
        # label = torch.nn.ReLU()(label3)
        # out_label = self.out(label)
        if in_feat:
            return label1, label2, label3, out_label
        else:
            return out_label