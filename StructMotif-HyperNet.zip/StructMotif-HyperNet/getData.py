import os

import torch
# from torch_geometric.data import DataLoader
from torch.utils.data import DataLoader
from y_util import build_protein_graph, parse_pdb_chains, load_sequence_labels, MultiFeatureDataset

from torch_geometric.data import Batch


def multi_feature_collate(batch):
    # 拆解四部分数据
    sequences, adj_edges, labels, hyper_edges = zip(*batch)

    # 处理固定维度部分
    seq_tensor = torch.stack(sequences, dim=0)  # (batch_size, 50)
    label_tensor = torch.stack(labels, dim=0)  # (batch_size,)

    # 处理变长邻接矩阵和超图（保持为列表）
    adj_list = list(adj_edges)  # 邻接边列表 [ (2, num_edges_1), ... ]
    hyper_list = list(hyper_edges)  # 超图边列表 [ (2, num_hyperedges_1), ... ]

    return {
        "seq": seq_tensor,
        "adj": adj_list,
        "label": label_tensor,
        "hyper": hyper_list
    }
def graphData(x_train0,x_test0,train_hyg,test_hyg):

    train_directory = '../train_pdb'
    train_files = os.listdir(train_directory)
    train_data_chains = []
    for file_name in train_files:
        file_path = os.path.join(train_directory, file_name)
        train_data_chains.append(parse_pdb_chains(file_path))
    train_seq,train_label = load_sequence_labels("../row_data/train.txt")

    i = 0
    train_adj = []
    for chains in train_data_chains:
        for chain in chains:

            train_adj.append(build_protein_graph(chain,x_train0[i],train_hyg[i]))

            i = i+1

    test_directory = '../test_pdb'
    test_files = os.listdir(test_directory)
    test_data_chains = []
    for file_name in test_files:
        file_path = os.path.join(test_directory, file_name)
        test_data_chains.append(parse_pdb_chains(file_path))
    test_seq,test_label = load_sequence_labels("../row_data/test.txt")

    j = 0
    test_adj = []
    for chains in test_data_chains:
        for chain in chains:
            # if j<len(test_hyg):


            test_adj.append(build_protein_graph(chain, x_test0[j],test_hyg[j]))

            j = j+1


    # dataset_train = CustomDataset(train_dataset, train_label)
    # train_loader = DataLoader(dataset_train, batch_size=256,shuffle=True)
    #
    # dataset_test = CustomDataset(test_dataset, test_label[:1919])
    # test_loader = DataLoader(dataset_test,batch_size=256)
    dataset_train = list(zip(x_train0, train_adj,train_label,train_hyg))
    # train_samples = [x_train0,train_adj,train_label,train_hyg]
    train_dataset = MultiFeatureDataset(dataset_train)
    train_loader = DataLoader(train_dataset, batch_size=256, collate_fn=multi_feature_collate)

    # test_samples = [x_test0, test_adj, test_label, test_hyg]
    test_samples = list(zip(x_test0, test_adj, test_label, test_hyg))
    test_dataset = MultiFeatureDataset(test_samples)
    test_loader = DataLoader(test_dataset, batch_size=256, collate_fn=multi_feature_collate)


    # dataset_train = list(zip(train_dataset, train_label))
    # dataset_test = list(zip(test_dataset, test_label))
    # dataset_train = DataLoader(dataset_train, batch_size=256, shuffle=True, pin_memory=True,
    #                            drop_last=True)
    # dataset_test = DataLoader(dataset_test, batch_size=256, shuffle=True, pin_memory=True,
    #                           drop_last=True)

    # 验证批次数据
    # sample_batch = next(iter(train_loader))
    # print("Batch hyg shape:", sample_batch[0].hyg.shape)  # 应输出 [32, 128]

    return train_loader,test_loader

