

from sklearn.metrics import confusion_matrix, roc_auc_score, matthews_corrcoef, auc
from sklearn.metrics import f1_score, accuracy_score, recall_score, precision_score, precision_recall_curve
import numpy as np


def scores(y_test, y_pred, th=0.5):
    """
    Calculate performance metrics for binary classification models

    Parameters:
    y_test: True labels
    y_pred: Predicted probabilities
    th: Threshold for classifying predictions (default=0.5)

    Returns:
    Tuple containing 13 performance metrics
    """
    # Convert predicted probabilities to binary labels using threshold
    y_predlabel = [(0 if item < th else 1) for item in y_pred]
    # Ensure true labels are binary (0/1)
    y_test = np.array([(0 if item < 1 else 1) for item in y_test])
    y_predlabel = np.array(y_predlabel)

    # Get confusion matrix components
    tn, fp, fn, tp = confusion_matrix(y_test, y_predlabel).flatten()

    # Calculate metrics
    SP = tn * 1.0 / ((tn + fp) * 1.0)  # Specificity
    SN = tp * 1.0 / ((tp + fn) * 1.0)  # Sensitivity
    MCC = matthews_corrcoef(y_test, y_predlabel)  # Matthews Correlation Coefficient
    Recall = recall_score(y_test, y_predlabel)
    Precision = precision_score(y_test, y_predlabel)
    F1 = f1_score(y_test, y_predlabel)  # F1-score
    Acc = accuracy_score(y_test, y_predlabel)  # Accuracy
    AUC = roc_auc_score(y_test, y_pred)  # Area Under ROC Curve
    # Calculate Area Under Precision-Recall Curve
    precision_aupr, recall_aupr, _ = precision_recall_curve(y_test, y_pred)
    AUPR = auc(recall_aupr, precision_aupr)  # Area Under PR Curve

    return Recall, SN, SP, MCC, Precision, F1, Acc, AUC, AUPR, tp, fn, tn, fp


def Aiming(y_hat, y):
    '''
    the “Aiming” rate (also called “Precision”) is to reflect the average ratio of the
    correctly predicted labels over the predicted labels; to measure the percentage
    of the predicted labels that hit the target of the real labels.
    '''
    # Get dimensions: n samples, m labels
    n, m = y_hat.shape
    sorce_k = 0  # Accumulator for scores

    # Calculate Aiming for each sample
    for v in range(n):
        union = 0
        intersection = 0
        # Check each label
        for h in range(m):
            if y_hat[v, h] == 1 or y[v, h] == 1:
                union += 1
            if y_hat[v, h] == 1 and y[v, h] == 1:
                intersection += 1

        # Skip if no correct predictions
        if intersection == 0:
            continue
        # Accumulate sample's Aiming score
        sorce_k += intersection / sum(y_hat[v])

    # Return average Aiming across samples
    return sorce_k / n


def Coverage(y_hat, y):
    '''
    The “Coverage” rate (also called “Recall”) is to reflect the average ratio of the
    correctly predicted labels over the real labels; to measure the percentage of the
    real labels that are covered by the hits of prediction.
    '''
    n, m = y_hat.shape
    sorce_k = 0

    for v in range(n):
        union = 0
        intersection = 0
        for h in range(m):
            if y_hat[v, h] == 1 or y[v, h] == 1:
                union += 1
            if y_hat[v, h] == 1 and y[v, h] == 1:
                intersection += 1

        if intersection == 0:
            continue
        # Calculate sample's Coverage score
        sorce_k += intersection / sum(y[v])

    return sorce_k / n


def Accuracy(y_hat, y):
    '''
    The “Accuracy” rate is to reflect the average ratio of correctly predicted labels
    over the total labels including correctly and incorrectly predicted labels as well
    as those real labels but are missed in the prediction
    '''
    n, m = y_hat.shape
    sorce_k = 0

    for v in range(n):
        union = 0
        intersection = 0
        for h in range(m):
            if y_hat[v, h] == 1 or y[v, h] == 1:
                union += 1
            if y_hat[v, h] == 1 and y[v, h] == 1:
                intersection += 1

        if intersection == 0:
            continue
        # Calculate sample's Accuracy score
        sorce_k += intersection / union

    return sorce_k / n


def AbsoluteTrue(y_hat, y):
    '''
    Proportion of samples with all labels predicted exactly correctly
    '''
    n, m = y_hat.shape
    score_k = 0  # Count of perfectly predicted samples

    # Check if all labels match for each sample
    for v in range(n):
        if list(y_hat[v]) == list(y[v]):
            score_k += 1

    # Return proportion of perfect predictions
    return score_k / n


def AbsoluteFalse(y_hat, y):
    '''
    hamming loss - average proportion of incorrectly predicted labels per sample
    '''
    n, m = y_hat.shape
    sorce_k = 0

    for v in range(n):
        union = 0
        intersection = 0
        for h in range(m):
            if y_hat[v, h] == 1 or y[v, h] == 1:
                union += 1
            if y_hat[v, h] == 1 and y[v, h] == 1:
                intersection += 1

        # Calculate Hamming loss for sample
        sorce_k += (union - intersection) / m

    return sorce_k / n


def evaluate(y_hat, y):
    """
    Evaluate multi-label classification performance

    Parameters:
    y_hat: Predicted label probabilities
    y: True labels

    Returns:
    Dictionary containing performance metrics
    """
    score_label = y_hat
    # Initialize metric lists
    aiming_list = []
    coverage_list = []
    accuracy_list = []
    absolute_true_list = []
    absolute_false_list = []

    # Convert probabilities to binary labels using 0.5 threshold
    for i in range(len(score_label)):
        for j in range(len(score_label[i])):
            if score_label[i][j] < 0.5:  # threshold
                score_label[i][j] = 0
            else:
                score_label[i][j] = 1

    y_hat = score_label  # Update to binary predictions

    # Calculate all metrics
    aiming = Aiming(y_hat, y)
    aiming_list.append(aiming)
    coverage = Coverage(y_hat, y)
    coverage_list.append(coverage)
    accuracy = Accuracy(y_hat, y)
    accuracy_list.append(accuracy)
    absolute_true = AbsoluteTrue(y_hat, y)
    absolute_true_list.append(absolute_true)
    absolute_false = AbsoluteFalse(y_hat, y)
    absolute_false_list.append(absolute_false)

    # Return metrics as dictionary
    return dict(aiming=aiming, coverage=coverage, accuracy=accuracy,
                absolute_true=absolute_true, absolute_false=absolute_false)