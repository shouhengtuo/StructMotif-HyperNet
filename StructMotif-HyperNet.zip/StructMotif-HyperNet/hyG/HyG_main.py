

import datetime
import os
import csv
import re
import numpy as np
import pandas as pd
from ..model import *
from torch.utils.data import DataLoader
from ..loss_functions import *
from HyG_train import CosineScheduler

from HyG_train import *
from HyGmodel import *
from seq_HyGAN import get_hyG
torch.autograd.set_detect_anomaly(True)
# DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
DEVICE = torch.device("cpu")
def main(num, data):
    # 获得图结构数据
    # 将测试数据与训练数据分开
    # sequence_X, train_data = get_hyG("./dataset/hyG_train.txt")
    # _, test_data = get_hyG("./dataset/hyG_test.txt")
    # 将全部数据都用来构造图数据，不分开测试数据与训练数据
    sequence_X, train_data = get_hyG("./dataset/target.txt")
    # 初始化模型
    model = Seq_HyGAN(sequence_X.shape[1], 64, 128, 128, 21, 0.3)
    rate_learning = data['learning_rate']
    optimizer = torch.optim.Adam(model.parameters(), lr=rate_learning)
    lr_scheduler = CosineScheduler(10000, base_lr=rate_learning, warmup_steps=500)
    criterion = nn.BCEWithLogitsLoss()
    Train = DataTrain(model, optimizer, criterion, lr_scheduler, device=DEVICE)
    # 训练模型（保存验证结果最好的模型），返回保存的最好的预测结果
    a = time.time()
    best_test_pred, test_label = Train.train_step(train_data, epochs=data['epochs'], plot_picture=False)
    b = time.time()
    # 计算训练时间
    runtime = b - a
    # 加载保存的模型进行测试
    best_test_pred, test_label = Train.load_model_test(model, train_data)
    test_score = hyG_evaluate(model, best_test_pred, test_label, device=DEVICE)

    # "-------------------------------------------保存模型参数-----------------------------------------------"
    # PATH = os.getcwd()
    # each_model = os.path.join(PATH, 'result', 'Model', 'teacher', 'tea_model' + str(num) + '.h5')
    # torch.save(model.state_dict(), each_model, _use_new_zipfile_serialization=False)
    # "---------------------------------------------------------------------------------------------------"

    "-------------------------------------------输出模型结果-----------------------------------------------"
    print(f"runtime:{runtime:.3f}s")
    print("测试集：")
    print(f'aiming: {test_score["aiming"]:.3f}')
    print(f'coverage: {test_score["coverage"]:.3f}')
    print(f'accuracy: {test_score["accuracy"]:.3f}')
    print(f'absolute_true: {test_score["absolute_true"]:.3f}')
    print(f'absolute_false: {test_score["absolute_false"]:.3f}')
    "---------------------------------------------------------------------------------------------------"

# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    clip_pos = 0.7
    clip_neg = 0.5
    pos_weight = 0.3

    batch_size = 192
    epochs = 500
    # epochs = 15
    # learning_rate = 0.0018
    learning_rate = 0.018

    embedding_size = 192
    dropout = 0.6
    fan_epochs = 1
    num_heads = 8
    para = {'clip_pos': clip_pos,
            'clip_neg': clip_neg,
            'pos_weight': pos_weight,
            'batch_size': batch_size,
            'epochs': epochs,
            'learning_rate': learning_rate,
            'embedding_size': embedding_size,
            'dropout': dropout,
            'fan_epochs': fan_epochs,
            'num_heads': num_heads}
    # 可以选择main函数执行多少遍
    # for i in range(5):
    #     main(i, para)

    main(1, para)