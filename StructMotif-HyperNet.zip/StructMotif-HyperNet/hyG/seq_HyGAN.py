import warnings
warnings.filterwarnings('ignore')
from HyGmodel import *
import numpy as np # linear algebra
import dgl
import torch
import torch.nn as nn
from scipy.sparse import coo_matrix
from sklearn.model_selection import train_test_split
from get_Gf import gen_gf
# from util_metric import caculate_metric

def get_hyG(raw_path):
# def get_hyG(label_path, hyg_path, nodes_num):
    '''
    converting to sparse matrix
    '''
    label, nodes_num, subseq_idx_tensor, seq_idxs_tensor = gen_gf(raw_path)

    # label_data=pd.read_csv(label_path, header=None)
    # label=label_data[0].tolist()

    # LEN=4936
    LEN=9792
    nl=coo_matrix((LEN, LEN))
    nl.setdiag(1)
    values = nl.data
    indices = np.vstack((nl.row, nl.col))
    i = torch.LongTensor(indices)
    v = torch.FloatTensor(values)
    shape = nl.shape
    nl=torch.sparse_coo_tensor(i, v, torch.Size(shape))
    nl=np.eye(LEN)
    nl=torch.from_numpy(nl)

    # chemicalsub_drug = torch.load(hyg_path)
    # data_dict = {
    #     ('node', 'in', 'edge'): (chemicalsub_drug[:, 0], chemicalsub_drug[:, 1]),
    #     ('edge', 'con', 'node'): (chemicalsub_drug[:, 1], chemicalsub_drug[:, 0])
    # }


    data_dict = {
            ('node', 'in', 'edge'): (subseq_idx_tensor, seq_idxs_tensor),
            ('edge', 'con', 'node'): (seq_idxs_tensor, subseq_idx_tensor)
        }



    '''
    finally passing the data_dict to construct hyG
    '''
    hyG = dgl.heterograph(data_dict)
    # 表示节点数量
    n_chemicalsub=nodes_num  #change the num of rows based on the dataset. row info. is available on data folder
    rows=n_chemicalsub
    n_hedge=LEN
    columns=n_hedge

    '''
    laoding the feature (one hot coding) for sequences (edges)
    '''
    # 边初始化 rows
    sequence_X=nl
    # 节点初始化，采用稀疏张量
    v_feat=coo_matrix((rows, 128))
    v_feat.setdiag(1)
    values = v_feat.data
    indices = np.vstack((v_feat.row, v_feat.col))
    i = torch.LongTensor(indices)
    v = torch.FloatTensor(values)
    shape = v_feat.shape
    v_feat=torch.sparse_coo_tensor(i, v, torch.Size(shape))

    hyG.ndata['h'] = {'edge' : sequence_X.type('torch.FloatTensor'), 'node' : v_feat.type('torch.FloatTensor')}
    e_feat = sequence_X.type('torch.FloatTensor')
    v_feat=v_feat.type('torch.FloatTensor')

    return sequence_X, dict(label=label, hyG=hyG, v_feat=v_feat, e_feat=e_feat)

